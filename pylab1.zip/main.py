# генерируем тестовый файл
with open('data.txt', 'w') as f:
    for num in [5, 12, 7, 9, 3, 15, 8, 6, 10, 4]:
        f.write(f"{num}\n")

with open('data.txt', 'r') as file:
    numbers = [int(line.strip()) for line in file]

result = {
    "Сумма": sum(numbers),
    "Среднее": sum(numbers) / len(numbers),
    "Максимум": max(numbers),
    "Минимум": min(numbers)
}

with open('result.txt', 'w') as file:
    for key, value in result.items():
        file.write(f"{key}: {value}\n")

print("Результаты сохранены в result.txt")
